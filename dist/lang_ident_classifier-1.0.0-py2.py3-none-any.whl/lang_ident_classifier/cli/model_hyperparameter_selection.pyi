from typing import Any, Dict, List, Optional, Tuple, Union

class DistributedPruner:
    def __init__(self, study, trial_number) -> Any: ...
    def on_validation_end(self, trainer, pl_module) -> Any: ...

def clear_checkpoints(log, model_config_name, study, trial) -> Any: ...
"""
Clear outdated checkpoint directories for the given model config.

Args:
    log (Logger): Logger instance.
    model_config_name (str): Model configuration name used to build checkpoint root path.
    study (optuna.Study): Optuna study object (kept in signature for compatibility).
    trial (optuna.trial.Trial): Current trial; its number is preserved.

Notes:
    - This function removes directories for older trials (non-current).
    - It will not raise if directories are missing; failures to remove are logged.
"""

def study_early_stopping(study, trial, log) -> Any: ...
"""
Global early stopping logic across trials using module-level patience counters.

Args:
    study (optuna.Study): Current Optuna study instance.
    trial (optuna.trial.Trial): Latest trial (kept for signature compatibility).
    log: Logger instance for logging messages.

Notes:
    - Relies on module-level globals: best_trial, no_improvement_count, patience.
    - When patience is exceeded, study.stop() is invoked and a distributed shutdown is attempted.
"""

def get_study_stats(study) -> Any: ...
"""
Return a human-readable summary of an Optuna study.

Args:
    study (optuna.Study): The Optuna study instance.

Returns:
    str: Multi-line string summarizing number of trials by state and best trial info.

Raises:
    None
"""

def cleanup_distributed() -> Any: ...

def testset_from_best_checkpoint_callback(args, study, trial, prompt_template, ignore_params, trainer_strategy, precision) -> Any: ...

def train_model(args, trial, study) -> Any: ...

def objective(trial, args, continue_optimization, study) -> Any: ...
"""
Objective function executed for each Optuna trial.

This wraps the entire lifecycle for a trial:
  - setup (seeding, GPU reset),
  - load/tokenize pretrained embedding,
  - prepare datasets and DataModule,
  - build model (optionally with LoRA),
  - train using a Lightning Trainer,
  - test using the best checkpoint and record metrics.

Args:
    trial (optuna.trial.Trial): Optuna trial instance (or None for worker-only invocation).
    args (Any): CLI parsed arguments (must include config_file_path, cpu_cores, num_nodes, etc.).
    continue_optimization (bool): Flag indicating whether to continue optimization (used for early termination).
    study (optuna.Study): Optuna study instance used to record trial-level metadata and interact with pruning.

Returns:
    Any: The value to be optimized (test accuracy recorded in trial.user_attrs).

Raises:
    optuna.exceptions.TrialPruned: Re-raises when trial is pruned.
    torch.cuda.OutOfMemoryError: Re-raises (after cleanup) to signal OOM to outer loop or Optuna.
    Exception: Any unexpected exception will be recorded on the trial and re-raised.
"""

def log_trial_results(model_config_name, log, study, trial, metrics_dir, trial_metrics_filename) -> Any: ...
"""
Logs the results of an Optuna trial for a given study.

Args:
    model_config_name (str): Model name or config identifier.
    log (Logger): Logger instance.
    study (optuna.Study): Optuna Study instance.
    trial (optuna.trial.Trial): Current Trial instance.
    metrics_dir (str): Directory to store metrics.
    trial_metrics_filename (str): Filename for the trial metrics.

Returns:
    None

Raises:
    OSError: If metrics directory cannot be created or file cannot be written.
"""

def resume_study_trial_execution(props, log, study, storage, run_timestamp, resume_from_trial_number) -> Any: ...
"""
A custom implementation to handle failures for interrupted Study.

Ensures the study is resumed with trials that are freshly created (within 5 minutes)
or already complete. If necessary, deletes the old study and creates a new one
containing only valid trials.

Args:
    props (Any): Properties object loaded from a YAML config file.
    log (Logger): Python logger object.
    study (optuna.Study): Optuna Study loaded from specified storage.
    storage (str|Any): Name of the storage location.
    run_timestamp (float): Timestamp when the run started (used to filter fresh trials).
    resume_from_trial_number (Optional[int]): If provided, resume from this trial number.

Returns:
    optuna.Study: Instance of Optuna Study with required trials loaded.

Raises:
    RuntimeError: If study loading or deletion fails.
"""

def create_new_study(props, log, lang_study_storage, hyperparam_sampler, study_pruner) -> Any: ...
"""
Create a new Optuna study with the provided sampler and pruner.

Args:
    props (Any): Properties object containing app.model_config_name.
    log (Any): Logger instance.
    lang_study_storage (optuna.storages.BaseStorage): Storage for the study.
    hyperparam_sampler (optuna.samplers.BaseSampler): Sampler to use for hyperparameters.
    study_pruner (optuna.pruners.BasePruner): Pruner to use for early pruning.

Returns:
    optuna.Study: Created or loaded study instance.

Raises:
    optuna.exceptions.OptunaError: If study creation fails for unexpected reasons.
"""

def run_app(args) -> Any: ...
"""
Launch method for the lang ident classifier app.

This initializes distributed state (if applicable), sets seeds, prepares
Optuna storage, sampler and pruner, and orchestrates study creation /
resumption and the optimization loop. It creates several small callback
wrappers that map back to helper functions defined in model_helper_utils.

Args:
    args (argparse.Namespace): Parsed command-line arguments. Expected fields include:
        - config_file_path (str): Path to YAML configuration file.
        - num_nodes (int): Number of GPU nodes.
        - cpu_cores (int): Number of CPU cores.
        - backend (str): Distributed backend ('gloo', 'mpi', or 'nccl').
        - run_timestamp (float): Timestamp for the run.

Returns:
    Any: None. Orchestrates optimization and returns when done.

Raises:
    FileNotFoundError: If the config file specified in args.config_file_path does not exist.
    RuntimeError: If distributed initialization fails.
    Exception: For other unexpected errors during study creation or optimization.
"""

def main() -> Any: ...
"""
Entrypoint for CLI execution.

Parses command-line arguments, sets a run timestamp if missing and calls run_app.
Ensures distributed groups are finalized on exit.

CLI args:
  --config_file_path (str, required)
  --resume_study_from_trial_number (int|None)
  --num_nodes (int)
  --cpu_cores (int)
  --local-rank (int)
  --backend (str)
  --run_timestamp (float)

Raises:
    SystemExit: Exits with code 0 upon normal completion.
    Exception: Propagates unexpected exceptions.
"""

__all__ = ['testset_from_best_checkpoint_callback', 'DistributedPruner', 'create_new_study', 'cleanup_distributed', 'main', 'clear_checkpoints', 'run_app', 'get_study_stats', 'resume_study_trial_execution', 'study_early_stopping', 'objective', 'train_model', 'log_trial_results']
