from typing import Any, Dict, List, Optional, Tuple, Union

def read_source(path) -> Any: ...

def write_file(path, text) -> Any: ...

def backup(path) -> Any: ...

def split_module(source, helper_names) -> Any: ...
"""
Parse source with ast, extract top-level imports, other top-level statements,
and split functions/classes in helper_names into helpers. Returns (helpers_src, main_src).
"""

def run() -> Any: ...

__all__ = ['read_source', 'write_file', 'backup', 'split_module', 'run']
