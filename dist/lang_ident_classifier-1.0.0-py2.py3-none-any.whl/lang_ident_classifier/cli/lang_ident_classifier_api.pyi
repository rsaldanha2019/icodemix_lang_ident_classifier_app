from typing import Any, Dict, List, Optional, Tuple, Union

def _ensure_component(name, comp) -> Any: ...

def _call_component(component, args) -> Any: ...
"""
Call a component which may be:
  - A callable (function/class) -> call it with args if it accepts one argument, otherwise call without args.
  - A module object -> try common entrypoint function names inside the module.

Entrypoint names tried (in order): run_app, run_finetune, run_train, run, cli_main, main, process
"""

def main() -> Any: ...

__all__ = ['_ensure_component', '_call_component', 'main']
