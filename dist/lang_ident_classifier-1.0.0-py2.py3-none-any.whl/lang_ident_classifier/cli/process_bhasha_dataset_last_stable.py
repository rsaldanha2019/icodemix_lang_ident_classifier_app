import importlib
_mod = importlib.import_module('._process_bhasha_dataset_last_stable', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
