from typing import Any, Dict, List, Optional, Tuple, Union

class OptunaLoggingCallback:
    def __init__(self, trial) -> Any: ...
    def on_train_start(self, trainer, pl_module) -> Any: ...

class GPUUsagePruneCallback:
    def __init__(self, trial, threshold) -> Any: ...
    """
    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage to trigger pruning.
    """
    def _check_gpu_usage(self, trainer) -> Any: ...
    def _broadcast_prune_flag(self, flag) -> Any: ...
    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx, dataloader_idx) -> Any: ...

def custom_wrap_policy(min_num_params) -> Any: ...

class CustomFSDPStrategy:
    def __init__(self, ig_params, ig_modules) -> Any: ...
    def lightning_restore_optimizer(self) -> Any: ...
    """
    Override to disable Lightning restoring optimizers/schedulers.

    This is useful for plugins which manage restoring optimizers/schedulers.
    """
    def lightning_module_state_dict(self) -> Any: ...
    def optimizer_state(self, optimizer) -> Any: ...
    """Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel."""

def adjust_local_gpu_rank() -> Any: ...
"""
Adjust local GPU rank based on CUDA_VISIBLE_DEVICES, LOCAL_RANK, and RANK.

Returns:
    int: local GPU rank inside visible devices (0-based).
         Returns -1 if CUDA not available (CPU).
"""

def get_device_info() -> Any: ...
"""
Generates Device information like CPU , GPU data for logging

Returns:
    dict: device information as a dictionary
"""

def remove_files_except(directory, file_to_keep, log) -> Any: ...
"""
Deletes files in specified directory except the one specified

Args:
    directory (str): target directory to search for files to be deleted
    file_to_keep (str): file path to retain
    log (Logger): logging instance
"""

def clear_checkpoints(log, model_config_name, study, trial) -> Any: ...
"""
Clears checkpoints during the recently executed Trial

Args:
    log (Logger): logging instance
    model_config_name (str): name of the model configuration
    study (optuna.Study): instance of optuna Study
    trial (optuna.trial.Trial): instance of study trial
"""

def study_early_stopping(study, trial, log) -> Any: ...
"""
Custom early stopping callback for Optuna study trials, with global patience.
Handles safe access to best_trial and ensures proper distributed shutdown.
"""

def get_study_stats(study) -> Any: ...
"""
Takes an instance of an Optuna Study and returns the study statistics.

Args:
    study (optuna.Study): Instance of the Optuna study.

Returns:
    str: Study statistics for trial states.
"""

def load_checkpoint_with_fsdp(model, fsdp_model, checkpoint_path) -> Any: ...
"""
Load a checkpoint into the original model when using FSDP.
Args:
    model: The original model instance (unwrapped).
    fsdp_model: The FSDP-wrapped model instance.
    checkpoint_path: Path to the checkpoint file.
"""

def get_lora_config(trial, target_modules, lora_task_type) -> Any: ...

def dequantize_bnb_model(model) -> Any: ...

def manual_dequantize(module) -> Any: ...
"""Recursively dequantize BNB layers in the model (skips non-quantized embeddings)."""

def testset_from_best_checkpoint_callback(args, study, trial, prompt_template, ignore_params, trainer_strategy, precision) -> Any: ...
"""Callback to compute test accuracy using the best checkpoint across all ranks."""

def get_trainable_parameters(model) -> Any: ...

def get_target_modules(model, attribute_filter, name_filter, custom_filter) -> Any: ...
"""
Identify target modules in a PyTorch or Lightning model based on configurable criteria.

Args:
    model (nn.Module or LightningModule): The model to analyze.
    attribute_filter (callable, optional): Function to filter modules by attributes 
        (e.g., lambda module: hasattr(module, "weight") and module.weight.numel() > 64).
    name_filter (callable, optional): Function to filter modules by name 
        (e.g., lambda name: "fc" in name).
    custom_filter (callable, optional): Function to filter modules by any custom logic 
        (e.g., lambda name, module: name.startswith("layer") and hasattr(module, "bias")).

Returns:
    dict: Dictionary where keys are module names and values are the corresponding module objects.
"""

def clear_gpu_and_cpu_resources() -> Any: ...
"""Safely clears GPU and CPU memory without disrupting distributed processes."""

def calculate_model_size_in_gb(model) -> Any: ...
"""
Calculate model size in GB by including all parameters across all layers and submodules,
ensuring no duplication.

Args:
    model (torch.nn.Module): PyTorch model.

Returns:
    float: Model size in GB.
"""

def get_model_summary(model, depth) -> Any: ...

def get_devices_for_trainer(DEVICE) -> Any: ...

def get_supported_compute_dtype() -> Any: ...

def objective(trial, args, continue_optimization, study) -> Any: ...
"""
This is the objective function used in an Optuna Study's Trial 
where the specified combination of parameters are experimented on and 
the monitored parameter value is returned

Args:
    trial (optuna.trial.Trial): An instance of an optuna Trial
    args (Any): arguments passed to the main function

Returns:
    Any: Value of the metric monitored during the Trial
"""

def log_trial_results(model_config_name, log, study, trial, metrics_dir, trial_metrics_filename) -> Any: ...
"""
Logs the results of an Optuna trial for a given study.

Args:
    model_config_name (str): Model name or config identifier.
    log (Logger): Logger instance.
    study (optuna.Study): Optuna Study instance.
    trial (optuna.trial.Trial): Current Trial instance.
    metrics_dir (str): Directory to store metrics.
    trial_metrics_filename (str): Filename for the trial metrics.
"""

def is_duplicate(trial, study) -> Any: ...

class NoDuplicateSampler:
    def __init__(self, base_sampler) -> Any: ...
    def infer_relative_search_space(self, study, trial) -> Any: ...
    def sample_relative(self, study, trial, search_space) -> Any: ...
    def sample_independent(self, study, trial, param_name, param_distribution) -> Any: ...

def resume_study_trial_execution(props, log, study, storage, run_timestamp, resume_from_trial_number) -> Any: ...
"""
A custom implementation to handle failures for interrupted Study.
Ensures the study is resumed with trials that are freshly created (within 5 minutes)
or already complete. Deletes the old study and creates a new one.

Args:
    props (Any): Properties object loaded from a YAML config file.
    log (Logger): Python logger object.
    study (optuna.Study): Optuna Study loaded from specified storage.
    storage (str|Any): Name of the storage location.

Returns:
    optuna.Study: Instance of Optuna Study with all required trials loaded.
"""

def gamma_for_tpe_sampler(n) -> Any: ...

def create_new_study(props, log, lang_study_storage, hyperparam_sampler, study_pruner) -> Any: ...

def run_app(args) -> Any: ...
"""
Launch method for the lang ident classifier app
:param args: takes command line arguments
:return: Any
"""

def main() -> Any: ...

__all__ = ['testset_from_best_checkpoint_callback', 'manual_dequantize', 'load_checkpoint_with_fsdp', 'clear_gpu_and_cpu_resources', 'get_trainable_parameters', 'dequantize_bnb_model', 'calculate_model_size_in_gb', 'remove_files_except', 'run_app', 'get_study_stats', 'get_lora_config', 'resume_study_trial_execution', 'get_model_summary', 'custom_wrap_policy', 'log_trial_results', 'adjust_local_gpu_rank', 'create_new_study', 'clear_checkpoints', 'GPUUsagePruneCallback', 'get_device_info', 'get_supported_compute_dtype', 'is_duplicate', 'objective', 'NoDuplicateSampler', 'OptunaLoggingCallback', 'main', 'gamma_for_tpe_sampler', 'CustomFSDPStrategy', 'study_early_stopping', 'get_devices_for_trainer', 'get_target_modules']
