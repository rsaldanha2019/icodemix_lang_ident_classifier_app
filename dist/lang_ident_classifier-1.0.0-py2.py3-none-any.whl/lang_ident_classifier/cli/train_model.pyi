from typing import Any, Dict, List, Optional, Tuple, Union

class CustomFSDPStrategy:
    def __init__(self, ig_params) -> Any: ...
    def lightning_restore_optimizer(self) -> Any: ...
    """
    Override to disable Lightning restoring optimizers/schedulers.

    This is useful for plugins which manage restoring optimizers/schedulers.
    """
    def lightning_module_state_dict(self) -> Any: ...
    def optimizer_state(self, optimizer) -> Any: ...

def adjust_local_gpu_rank() -> Any: ...

def get_device_info() -> Any: ...

def main(args) -> Any: ...
"""
Launch method for the lang ident classifier app
:param args: takes command line arguments
:return: None
"""

__all__ = ['CustomFSDPStrategy', 'adjust_local_gpu_rank', 'get_device_info', 'main']
