from typing import Any, Dict, List, Optional, Tuple, Union

class LanguageIdentificationClassifier:
    """Classifier for language identification using a transformer-based model."""
    def __init__(self, pretrained_embedding_model, class_names, lr, optimizer, class_weights, device_dict, num_backbone_model_units_unfrozen, loss_type, num_fc_layers, activation_function_for_layer, add_dropout_after_embedding, is_train, tokenizer, random_seed, pretrained_model_embedding_name, trial_number, decision_threshold, model_config_name, alpha, gamma) -> Any: ...
    """
    Initialize the language identification classifier.

    Args:
        pretrained_embedding_model (torch.nn.Module): Pretrained transformer model.
        class_names (List[str]): List of class names.
        lr (float): Learning rate.
        optimizer (str): Optimizer name (adamw, adamax, adam).
        class_weights (torch.Tensor): Class weights for loss computation.
        device_dict (Dict): Device configuration.
        num_backbone_model_units_unfrozen (int): Number of backbone layers to unfreeze.
        loss_type (str): Type of loss function.
        num_fc_layers (int): Number of fully connected layers.
        activation_function_for_layer (str): Activation function for FC layers.
        add_dropout_after_embedding (bool): Whether to add dropout after embedding.
        is_train (bool): Training mode flag.
        tokenizer (object): Tokenizer instance.
        random_seed (int): Random seed for reproducibility.
        pretrained_model_embedding_name (Optional[str]): Name of pretrained embedding model.
        trial_number (Optional[int]): Trial number for experiment tracking.
        decision_threshold (float): Threshold for unknown class detection.
        model_config_name (Optional[str]): model_config_name to create hold metrics in dir

    Raises:
        ValueError: If invalid parameters are provided.
    """
    def _setup_fc_layers(self) -> Any: ...
    """
    Set up fully connected layers with optional activation functions.

    Raises:
        RuntimeError: If layer setup fails.
    """
    def _setup_loss_function(self, loss_type) -> Any: ...
    """
    Initialize the loss function based on the specified type.

    Args:
        loss_type (str): Type of loss function.

    Raises:
        ValueError: If loss_type is unsupported.
    """
    def _reset_metrics_to_device(self) -> Any: ...
    def register_nan_hooks(self, module, prefix) -> Any: ...
    """
    Recursively attach hooks to detect NaNs in forward pass.

    Args:
        module (torch.nn.Module): Module to attach hooks to.
        prefix (str): Prefix for module naming.

    Raises:
        RuntimeError: If hook registration fails.
    """
    def has_trainable_params(self, module) -> Any: ...
    """
    Check if a module has trainable parameters.

    Args:
        module (torch.nn.Module): Module to check.

    Returns:
        bool: True if module has trainable parameters.
    """
    def fix_embedding_layers(self) -> Any: ...
    """
    Convert specific layers to float32 and wrap them for stability.

    Raises:
        RuntimeError: If layer wrapping fails.
    """
    def get_parent_and_attr(self, module_name) -> Any: ...
    """
    Find parent module and attribute name for a given module path.

    Args:
        module_name (str): Full module path.

    Returns:
        Tuple[Optional[torch.nn.Module], Optional[str]]: Parent module and attribute name.

    Raises:
        RuntimeError: If module path is invalid.
    """
    def _get_activation_function_instance(self, activation_function, num_parameters) -> Any: ...
    """
    Get activation function instance.

    Args:
        activation_function (str): Name of the activation function.
        num_parameters (int): Number of parameters for the activation.

    Returns:
        torch.nn.Module: Activation function instance.

    Raises:
        ValueError: If activation function is unsupported.
    """
    def initialize_weights(self, device, num_fc_layers) -> Any: ...
    """
    Initialize weights for fully connected layers.

    Args:
        device (torch.device): Device to initialize weights on.
        num_fc_layers (int): Number of fully connected layers.

    Raises:
        RuntimeError: If weight initialization fails.
    """
    def forward(self, input_ids) -> Any: ...
    def compute_auxiliary_distill_term(self, task_loss, kl_batch, contrast_batch) -> Any: ...
    """
    Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
    Uses cached self._last_teacher_conf (if available) for gating w.
    Returns dict with aux_term and diagnostics for logging.
    """
    def compute_kl_contrastive_loss(self, new_emb, old_emb, device) -> Any: ...
    """
    Compute KL divergence and contrastive loss between new and old embeddings.
    Automatically switches to chunked mode for large batches to save memory.

    Args:
        new_emb (torch.Tensor): New embeddings (student).
        old_emb (torch.Tensor): Old embeddings (teacher, detached).
        device (str): Target device for computation.

    Returns:
        Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
    """
    def training_step(self, batch, batch_idx) -> Any: ...
    """
    Perform a training step.

    Args:
        batch (Dict): Batch containing input_ids and labels.
        batch_idx (int): Batch index.

    Returns:
        torch.Tensor: Combined loss.

    Raises:
        RuntimeError: If training step fails.
    """
    def on_train_epoch_start(self) -> Any: ...
    def on_train_start(self) -> Any: ...
    """
    SequentialLR Sync Version.
    Restores the trainer clock and forces sub-scheduler alignment.
    """
    def on_train_epoch_end(self) -> Any: ...
    """
    Handle end of training epoch.

    Raises:
        RuntimeError: If epoch end processing fails.
    """
    def validation_step(self, batch, batch_idx) -> Any: ...
    """
    Perform a validation step.

    Args:
        batch (Dict): Batch containing input_ids, labels, and metadata.
        batch_idx (int): Batch index.

    Returns:
        Dict: Validation outputs.

    Raises:
        RuntimeError: If validation step fails.
    """
    def _save_metrics_to_csv(self, metrics_dict, filename, trial_number) -> Any: ...
    """
    Save metrics to a CSV file.

    Args:
        metrics_dict (Dict): Metrics to save.
        filename (str): Output filename.
        trial_number (Optional[int]): Trial number for directory.

    Raises:
        RuntimeError: If saving to CSV fails.
    """
    def on_validation_start(self) -> Any: ...
    def on_validation_epoch_end(self) -> Any: ...
    """
    Handle end of validation epoch.

    Raises:
        RuntimeError: If validation epoch end processing fails.
    """
    def reconcile_chunks(self, outputs) -> Any: ...
    """
    Reconcile chunked predictions and labels.

    Args:
        outputs (List[Dict]): Validation/test outputs.

    Returns:
        Tuple[torch.Tensor, torch.Tensor]: Reconciled predictions and labels.

    Raises:
        RuntimeError: If reconciliation fails.
    """
    def test_step(self, batch, batch_idx) -> Any: ...
    """
    Perform a test step.

    Args:
        batch (Dict): Batch containing input_ids, labels, and metadata.
        batch_idx (int): Batch index.

    Returns:
        Dict: Test outputs.

    Raises:
        RuntimeError: If test step fails.
    """
    def on_test_start(self) -> Any: ...
    def on_test_epoch_end(self) -> Any: ...
    """
    Handle end of test epoch.

    Raises:
        RuntimeError: If test epoch end processing fails.
    """
    def predict_step(self, batch, batch_idx, dataloader_idx) -> Any: ...
    """
    Perform a prediction step.

    Args:
        batch (Dict): Batch containing input_ids.
        batch_idx (int): Batch index.
        dataloader_idx (int): Dataloader index.

    Returns:
        Dict: Predictions and probabilities.

    Raises:
        RuntimeError: If prediction step fails.
    """
    def on_before_optimizer_step(self, optimizer) -> Any: ...
    """
    Handle operations before optimizer step.

    Args:
        optimizer: Optimizer instance.
    """
    def on_after_optimizer_step(self, optimizer) -> Any: ...
    """
    Handle operations after optimizer step.

    Args:
        optimizer: Optimizer instance.

    Raises:
        RuntimeError: If parameter clamping fails.
    """
    def _compute_grad_norm(self) -> Any: ...
    """
    Compute gradient norm.

    Returns:
        float: L2 gradient norm.

    Raises:
        RuntimeError: If gradient norm computation fails.
    """
    def configure_optimizers(self) -> Any: ...
    """
    Configure optimizer and learning rate scheduler.

    Returns:
        Dict: Optimizer and scheduler configuration.

    Raises:
        RuntimeError: If optimizer configuration fails.
    """

__all__ = ['LanguageIdentificationClassifier']
