import importlib
_mod = importlib.import_module('._wrking_gen_llm_language_identification_classifier_working_test_small_confusion_matrix', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
