import importlib
_mod = importlib.import_module('._oldgen_llm_language_identification_classifier', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
