from typing import Any, Dict, List, Optional, Tuple, Union

class LoggingCallback:
    """
    Callback that centralizes logging and metrics summary creation for training runs.

    Purpose
    -------
    - Log environment and trainer startup information.
    - Persist per-epoch metric rows to CSV (human-readable, deterministic formatting).
    - Produce a concise model summary table with parameter counts and estimated shard sizes
      for FSDP/DDP scenarios.
    - Emit informational messages on fit/test lifecycle events and on exceptions.

    Design goals
    ------------
    - Fail early for clearly invalid initialization inputs.
    - Keep all runtime behaviors unchanged from original implementation (no algorithmic changes).
    - Use `rank_zero_only` for actions that should only run on the primary process.
    - Provide clear docstrings and explicit `RuntimeError` on invalid usage.

    Parameters
    ----------
    log : logging.Logger
        Logger instance used for writing human-readable logs.
    model_summary_callback : object
        Object providing `_summary(trainer, pl_module)` (used to obtain model summary text).
    metrics_summary_dict : dict
        Mutable dictionary which will be updated with run-level summary metrics (start/end times, trial).
    metrics_dir : str
        Directory where per-epoch metrics CSV and summary file will be written.
    model_epoch_metrics_file : str
        Filename for per-epoch metrics CSV (written inside metrics_dir).
    model_metrics_summary_file : str
        Filename for aggregated model metrics summary CSV (written inside metrics_dir).
    random_seed : int, optional
        RNG seed used to produce reproducible logging and rounding behavior (default: 20).
    trial : optuna.trial.Trial, optional
        Optional Optuna trial object; if given, `trial.number` will be recorded in summary.

    Raises
    ------
    RuntimeError
        If required arguments are missing or invalid (e.g., `log` is None or metrics paths are invalid).
    """
    def __init__(self, log, model_summary_callback, metrics_summary_dict, metrics_dir, model_epoch_metrics_file, model_metrics_summary_file, random_seed, trial) -> Any: ...
    def on_train_start(self, trainer, pl_module) -> Any: ...
    """
    Called once at the beginning of training. Logs environment information such as GPU model,
    world size and rank, and dataset sampling summary for distributed runs.
    """
    def _fixed_float(self, val, precision) -> Any: ...
    """
    Deterministically round a float using Decimal with ROUND_HALF_UP semantics.

    Parameters
    ----------
    val : float
        Value to round.
    precision : int
        Number of decimal places.

    Returns
    -------
    float
        Rounded float.
    """
    def on_train_epoch_end(self, trainer, pl_module) -> Any: ...
    """
    At the end of each training epoch, capture metrics from the trainer, sanitize them,
    and append a row to the epoch metrics CSV. Also logs summary messages and LR info.

    Behavior
    --------
    - Writes a CSV line to `metrics_dir/model_epoch_metrics_file`.
    - Updates `metrics_summary_dict` start_epoch if not previously set.
    - Formats lambda values to two decimal string for consistent CSV representation.

    Exceptions
    ----------
    Raises RuntimeError if writing to the metrics CSV fails due to I/O errors.
    """
    def calculate_model_size_in_gb(self, model) -> Any: ...
    """
    Calculate the approximate size of the model in GB by summing unique parameter storage.

    Notes
    -----
    - When model is wrapped by FSDP and not in IDLE state, skip to avoid accessing FSDP internals unsafely.
    - Avoid double-counting shared parameter objects by tracking `id(param)`.

    Returns
    -------
    float
        Total model size in GiB (approximate).
    """
    def _filter_summary(self, trainer, depth, exclude) -> Any: ...
    """
    Produce a concise table-based model summary (layer name, type, params, trainable/non-trainable)
    and a small metrics table describing full model size vs shard estimates.

    Parameters
    ----------
    trainer : pl.Trainer
        Trainer used to determine strategy and unwrap FSDP if present.
    depth : int
        Depth of module naming to display; modules whose dotted name has depth >= this will be skipped.
    exclude : list[str] or None
        List of substrings; if a module's name contains any exclude token it will not be shown.

    Returns
    -------
    str
        Human-readable summary string including a PrettyTable of layers and summary metrics.
    """
    def on_fit_start(self, trainer, pl_module) -> Any: ...
    """
    Called when fitting begins. Records training start time and logs a model summary.
    If the model has no trainable parameters, sets trainer.should_stop to True to avoid wasted compute.
    """
    def on_test_start(self, trainer, pl_module) -> Any: ...
    """Called at the start of testing. Logs a model summary for easier debugging."""
    def on_exception(self, trainer, pl_module, exception) -> Any: ...
    """Called when an exception bubbles up during training. Log final training info to disk for debugging."""
    def on_fit_end(self, trainer, pl_module) -> Any: ...
    """Called at normal completion of training. Finalizes and writes summary metrics."""
    def _log_model_training_info(self, trainer, pl_module, message) -> Any: ...
    """
    Internal helper to persist final training summary information and write the metrics summary CSV.

    This aggregates start/end times, computes elapsed training time, persists summary to disk,
    and logs the same model summary computed earlier.
    """
