import importlib
_mod = importlib.import_module('._custom_log_callback', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
