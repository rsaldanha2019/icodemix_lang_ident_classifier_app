from typing import Any, Dict, List, Optional, Tuple, Union

class CustomGroupBySampleDistributedSampler:
    """
    Distributed sampler that assigns *all chunks* belonging to the same `sample_id`
    to the same rank. This avoids splitting a logical sample across multiple ranks
    and keeps chunk-group integrity during distributed training.

    Key guarantees:
      * All chunks for a single sample_id are yielded by the same rank.
      * Each rank receives roughly the same number of sample groups. If needed,
        groups are duplicated to ensure equal-length iterables across ranks
        (prevents starvation when using DistributedDataParallel).
      * Supports optional shuffling deterministic by (seed + epoch).

    Usage example
    -------------
    >>> sampler = CustomGroupBySampleDistributedSampler(dataset, shuffle=True, seed=42)
    >>> dataloader = torch.utils.data.DataLoader(dataset, sampler=sampler, ...)
    >>> for epoch in range(epochs):
    ...     sampler.set_epoch(epoch)
    ...     for batch in dataloader:
    ...         ...

    Notes
    -----
    - `dataset` is expected to be indexable (len(dataset) and dataset[i]) and each item
      must be a mapping that contains at least the keys: "sample_id" and "chunk_id".
    - The internal algorithm preserves your original final `__iter__` behavior.
    - This sampler returns an iterator of dataset indices (ints).

    Exceptions
    ----------
    RuntimeError
        Raised if `dataset` length is zero or items do not contain required keys.
    """
    def __init__(self, dataset, num_replicas, rank, shuffle, seed, drop_last) -> Any: ...
    """
    Initialize sampler.

    Parameters
    ----------
    dataset:
        Indexable dataset where each element is a mapping containing keys
        "sample_id" and "chunk_id". Example: dataset[i]["sample_id"] -> int.
    num_replicas:
        Number of distributed replicas (world size). If None and distributed
        is initialized, this will be read from torch.distributed.
    rank:
        The rank of the current process. If None and distributed is initialized,
        this will be read from torch.distributed.
    shuffle:
        Whether to shuffle sample groups each epoch (deterministic using seed+epoch).
    seed:
        Base seed for shuffling (combined with epoch).
    drop_last:
        Not used by the current algorithm, kept for API compatibility.
    """
    def __iter__(self) -> Any: ...
    """
    Produce an iterator of dataset indices for the current rank and epoch.

    Behavior (preserves original algorithm):
      - Build a list of sample_ids and optionally shuffle them using (seed + epoch).
      - Partition sample_ids by contiguous blocks to each rank.
      - For the current rank, collect all chunk indices for its sample groups.
      - If a rank has fewer chunks than the target `chunks_per_rank`, duplicate
        groups from its assigned set (round-robin) until the length reaches the target.
      - Return an iterator over the resulting list of indices.

    Returns
    -------
    Iterator[int]
        Iterator yielding dataset indices in the order chosen for the current rank.

    Raises
    ------
    RuntimeError
        If the sampler cannot construct a valid index list (e.g. no sample groups).
    """
    def __len__(self) -> Any: ...
    """
    Return the target number of indices this sampler will yield for the rank.

    This value is computed during initialization as the maximum chunk-count that any
    rank would receive when partitioning sample groups contiguously. It is used by
    PyTorch internals and DataLoader to determine epoch length for the rank.

    Returns
    -------
    int
        Number of indices expected from this sampler for one epoch.
    """
    def set_epoch(self, epoch) -> Any: ...
    """
    Set the epoch for this sampler. When `shuffle=True`, this influences the RNG
    used for shuffling sample groups so different epochs see different permutations.

    Parameters
    ----------
    epoch : int
        Epoch number (non-negative).

    Raises
    ------
    RuntimeError
        If epoch is not an integer or is negative.
    """

__all__ = ['CustomGroupBySampleDistributedSampler']
