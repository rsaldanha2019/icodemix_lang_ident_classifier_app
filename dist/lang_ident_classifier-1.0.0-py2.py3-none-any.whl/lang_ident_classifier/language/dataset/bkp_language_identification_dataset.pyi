from typing import Any, Dict, List, Optional, Tuple, Union

class LanguageIdentificationDataset:
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """
    def __init__(self, data_dir, files_have_header, pretrained_embedding_tokenizer, max_seq_length, classes_config_path, log, is_train, is_test, sample_dataset_share, num_workers, random_seed, is_gen_llm, prompt_template) -> Any: ...
    """
    Initialize dataset.

    :param data_dir: Root directory containing per-language subdirectories
                     with `src` and `tgt` files.
    :param files_have_header: If True, skip first line in files.
    :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
    :param max_seq_length: maximum token length per chunk.
    :param classes_config_path: path to JSON file with classes mapping.
    :param log: logger instance for informational messages.
    :param is_train: True when preparing training splits (affects class updates).
    :param is_test: True when running test/inference mode.
    :param sample_dataset_share: fraction of each file to sample (0..1).
    :param num_workers: number of worker threads for parallel processing.
    :param random_seed: RNG seed for deterministic sampling.
    :param is_gen_llm: if True, produce generative-LLM style chunks.
    :param prompt_template: used by generative LLM preparation.
    """
    def __len__(self) -> Any: ...
    """Number of chunked samples in the dataset (after preprocessing)."""
    def __getitem__(self, idx) -> Any: ...
    """
    Return the idx-th chunk as a dict suitable for collate functions:
    {
      "lang_code": str,
      "input_ids": torch.LongTensor,
      "labels": torch.LongTensor,
      "sample_id": int,
      "chunk_id": int,
      "word_positions": list[int],
      "prompt_len": int,
      "num_chunks": int
    }
    """
    def _get_class_id_from_lang_code(self, lang_code) -> Any: ...
    """Return numeric class id for a given language code; fallback -1 or unk id."""
    def _get_lang_code_from_class_id(self, class_id) -> Any: ...
    """Reverse mapping; assumes class_id present."""
    def get_num_classes(self) -> Any: ...
    def _add_languages(self, lang_code_dict) -> Any: ...
    """
    Inspect processed file data and update/augment lang_code_dict with languages
    observed in the dataset. This function counts tokens/labels to decide
    lang sample sizes and merges file-level stats.
    """
    def _normalize_class_weights(self, weights) -> Any: ...
    def _get_class_weights(self, classes_dict) -> Any: ...
    def _get_classes_dict(self, classes_config_path, is_train) -> Any: ...
    """
    Load classes mapping (JSON). If `is_train` is True the function will discover
    languages in the processed data and update the classes JSON on disk.
    """
    def get_labels(self) -> Any: ...
    """Return labels for the entire dataset (useful for e.g. class balancing)."""
    def _calculate_overlap(self, overlap_percentage) -> Any: ...
    """
    Return number of tokens to overlap given an overlap percentage of max_seq_length.
    Useful for sliding-window chunking.
    """
    def _is_arabic(text) -> Any: ...
    """Return True if all characters in text belong to Arabic script (approx.)."""
    def _reverse_arabic_sentence(sentence) -> Any: ...
    """
    When sentence is Arabic script, reverse the order of words to better handle
    right-to-left tokenization peculiarities in certain tokenizers.
    """
    def _similar_name(self, name_1, name_2) -> Any: ...
    """Return similarity ratio between two filenames; kept for optional diagnostics."""
    def process_batch_classifier(args) -> Any: ...
    """
    Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
    Returns (results_list, local_label_counter)
    """
    def process_batch_gen_llm_classifier(args) -> Any: ...
    """
    Construct chunks for generative LLM framing.
    The function follows the previously specified format:
      - Insert single space tokens between words in both streams.
      - word_positions contains per-label-token positions and -1 entries for spaces.
      - Overlap computed in WORDS, not tokens.
    """
    def _process_file_data(self, src_file, tgt_file, start_sample_id) -> Any: ...
    """
    Process a single pair of source and target files, chunk them and return:
     (lang_code, list_of_chunks, number_of_source_lines_processed)
    This method uses multiprocessing.dummy Pool to parallelize at the batch level.
    """
    def _validate_and_load_file_data(self) -> Any: ...
    """
    Discover language directories under `data_dir`, find matching src/tgt files,
    process them and append chunk results into self.file_data_dict_list.
    Performs validation such as file counts matching per-language and raises
    informative errors when mismatch detected.
    """
    def audit_dataset(self) -> Any: ...
    """
    Run a set of sanity checks on the processed `file_data_dict_list`.
    Raises ValueError when structural inconsistencies are detected.
    """
    def actual_dataset_length(self) -> Any: ...
    """Return number of unique base samples (unique sample_id)."""
    def actual_num_of_labels(self) -> Any: ...
    """
    Total number of label tokens across unique samples, counting unique
    word_positions per sample to avoid double-counting overlapping windows.
    """

__all__ = ['LanguageIdentificationDataset']
