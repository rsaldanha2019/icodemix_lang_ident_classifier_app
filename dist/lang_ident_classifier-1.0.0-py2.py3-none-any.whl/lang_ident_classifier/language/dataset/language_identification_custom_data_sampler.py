import importlib
_mod = importlib.import_module('._language_identification_custom_data_sampler', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
