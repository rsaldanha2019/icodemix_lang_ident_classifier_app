from typing import Any, Dict, List, Optional, Tuple, Union

class LanguageIdentificationDataModule:
    """
    Lightning DataModule for language identification workloads.

    This DataModule is a thin wrapper around dataset objects of type
    `LanguageIdentificationDataset` (or compatible indexable mappings) and provides
    train/val/test/predict DataLoaders. It preserves your original behavior:
      * Uses `CustomGroupBySampleDistributedSampler` when `torch.distributed` is enabled
        so that chunks belonging to the same sample_id are kept on the same rank.
      * Uses deterministic shuffling via a combination of `seed + epoch`.
      * Collation pads sequences with tokenizer's pad token (or eos token for gen-LLM special-case).

    Example
    -------
    >>> dm = LanguageIdentificationDataModule(
    ...     train_dataset=train_ds,
    ...     val_dataset=val_ds,
    ...     test_dataset=test_ds,
    ...     is_gen_llm=True,
    ...     batch_size=8,
    ...     num_workers=4,
    ...     tokenizer=my_tokenizer,
    ...     train_data_shuffle=True,
    ...     random_seed=42,
    ... )
    >>> dm.prepare_data()
    >>> dm.setup()
    >>> train_loader = dm.train_dataloader()

    Notes
    -----
    - `LanguageIdentificationDataset` must be indexable and return dict-like items
      with keys used later in `collate_fn` ('input_ids','labels','sample_id','chunk_id','word_positions','num_chunks', ...).
    - When `is_gen_llm=True` the module ensures `tokenizer.pad_token_id` is present and uses a special fallback value
      (this mirrors your original code's TODO/hardcoding).
    - This class intentionally raises `RuntimeError` for invalid configurations (missing tokenizer when needed,
      empty datasets, or non-indexable datasets) so failures are visible early.

    Parameters
    ----------
    train_dataset, val_dataset, test_dataset, predict_dataset:
        Instances of `LanguageIdentificationDataset` (or compatible). Any can be `None` if not used.
    is_gen_llm:
        If True, special padding/behavior for generative-LLM-style models is enabled.
    batch_size:
        Batch size to use for all DataLoaders.
    num_workers:
        Number of worker processes for data loading.
    tokenizer:
        Tokenizer object expected to provide `pad_token_id` and `eos_token_id`.
        Required when `is_gen_llm` is True.
    train_data_shuffle:
        Whether to shuffle training sample groups each epoch.
    random_seed:
        Global seed used for deterministic shuffling and worker initialization.

    Raises
    ------
    RuntimeError
        If `is_gen_llm` is True but `tokenizer` is None, or if any provided dataset is empty
        or not sized/indexable.
    """
    def __init__(self, train_dataset, val_dataset, test_dataset, predict_dataset, is_gen_llm, batch_size, num_workers, tokenizer, train_data_shuffle, random_seed) -> Any: ...
    def worker_init_fn(self, worker_id) -> Any: ...
    """
    Initialize each DataLoader worker with a deterministic seed derived from the
    global seed and the worker id so that shuffling and augmentations remain reproducible.

    Parameters
    ----------
    worker_id : int
        Worker process id (provided by DataLoader).
    """
    def train_dataloader(self) -> Any: ...
    """
    Build the training DataLoader.

    Returns
    -------
    DataLoader or None
        DataLoader configured for training, or None if no train_dataset was supplied.

    Behavior / Notes
    ----------------
    - When distributed training is active (torch.distributed.is_initialized()),
      uses `CustomGroupBySampleDistributedSampler` to keep chunks for the same sample on the same rank.
    - When single-process, uses standard DataLoader shuffle flag controlled by `train_data_shuffle`.
    """
    def val_dataloader(self) -> Any: ...
    """
    Build the validation DataLoader.

    Returns
    -------
    DataLoader or None
        Validation DataLoader or None if no val_dataset was supplied.
    """
    def test_dataloader(self) -> Any: ...
    """
    Build the test DataLoader.

    Returns
    -------
    DataLoader or None
        Test DataLoader or None if no test_dataset supplied.
    """
    def predict_dataloader(self) -> Any: ...
    """
    Build the prediction DataLoader.

    Returns
    -------
    DataLoader or None
        Predict DataLoader or None if no predict_dataset supplied.
    """
    def pad_sequence_left(sequences, batch_first, padding_value) -> Any: ...
    """
    Exact equivalent of torch.nn.utils.rnn.pad_sequence,
    but pads on the LEFT instead of the right.
    """
    def collate_fn(self, batch) -> Any: ...
    """
    Collate a list of dataset items into a batch used by the model.

    Parameters
    ----------
    batch : sequence of dict-like
        Each element is expected to contain keys:
        - "lang_code", "input_ids", "labels",
        - "sample_id", "chunk_id", "word_positions", "num_chunks"
        and optionally "prompt_len".

    Returns
    -------
    dict
        A mapping with keys:
        "lang_codes", "input_ids", "labels", "sample_ids", "chunk_ids",
        "word_positions", "prompt_lens", "num_chunks"
    """
