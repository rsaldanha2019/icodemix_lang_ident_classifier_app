from typing import Any, Dict, List, Optional, Tuple, Union

class MetricAwareAdaptiveLossUpdater:
    def update(criterion, new_weights) -> Any: ...

__all__ = ['MetricAwareAdaptiveLossUpdater']
