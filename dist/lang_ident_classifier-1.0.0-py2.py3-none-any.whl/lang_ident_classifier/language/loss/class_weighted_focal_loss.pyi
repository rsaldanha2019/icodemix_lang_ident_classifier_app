from typing import Any, Dict, List, Optional, Tuple, Union

class ClassWeightedFocalLoss:
    """
    Implements a class-weighted focal loss function with optional per-token weighting.

    This loss combines focal scaling with class or token-specific weights to handle
    class imbalance in sequence-level or token-level classification tasks.
    """
    def __init__(self, device, alpha, gamma, reduction, random_seed, ignore_index, separator_token) -> Any: ...
    """
    Initialize the weighted focal loss module.

    Args:
        device: Computation device, e.g., 'cpu' or 'cuda'.
        alpha: Class weighting factor. Can be a scalar or a dictionary mapping
            class labels to weights.
        gamma: Focusing parameter that controls down-weighting of easy examples.
        reduction: Reduction method to apply to the final loss. Options: 'mean', 'sum', or 'none'.
        random_seed: Random seed for reproducibility.
        ignore_index: Label index to ignore during loss computation.
        separator_token: Optional special token to assign custom weight.
    """
    def get_normalized_alpha(self, alpha) -> Any: ...
    def _build_token_weight_map(self, alpha_dict) -> Any: ...
    """
    Build a mapping from token IDs to weights based on the provided alpha dictionary.

    Args:
        alpha_dict: Dictionary mapping class or token identifiers to their respective weights.

    Returns:
        dict: Token ID to weight mapping.

    Raises:
        ValueError: If token IDs or weights are invalid.
    """
    def _generate_token_weight_mask(self, labels) -> Any: ...
    """
    Generate a per-token weight mask for the provided label tensor.

    Args:
        labels: Tensor of target labels (token IDs).

    Returns:
        torch.Tensor: A float tensor of the same shape as labels, where each entry
        represents the weight assigned to that token.

    Raises:
        RuntimeError: If label tensor shape is incompatible or mapping fails.
    """
    def forward(self, logits, targets) -> Any: ...
    """
    Compute the focal loss with class or token weighting.

    Args:
        logits: Predicted unnormalized scores (logits) from the model, of shape (..., num_classes).
        targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

    Returns:
        torch.Tensor: Scalar loss value after applying reduction.

    Raises:
        RuntimeError: If loss computation fails.
    """
