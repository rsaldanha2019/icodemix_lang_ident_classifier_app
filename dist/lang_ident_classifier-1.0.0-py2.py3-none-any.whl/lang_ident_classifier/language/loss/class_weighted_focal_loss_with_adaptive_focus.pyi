from typing import Any, Dict, List, Optional, Tuple, Union

class ClassWeightedFocalLossWithAdaptiveFocus:
    """
    Implements a class-weighted focal loss with an adaptive focusing mechanism.

    This loss extends the traditional focal loss by dynamically adjusting the
    focusing parameter (gamma) during training. It supports both scalar and
    per-token weighting schemes, allowing better handling of class imbalance
    and sequence-level label variability.
    """
    def __init__(self, device, alpha, gamma, reduction, gamma_type, random_seed, ignore_index, separator_token) -> Any: ...
    """
    Initialize the adaptive focal loss module.

    Args:
        device: Target computation device ('cpu' or 'cuda').
        alpha: Class weighting factor. Can be a scalar or a dictionary mapping
            class labels to (token_ids, weight) tuples.
        gamma: Base focusing parameter controlling how easily classified examples
            are down-weighted.
        reduction: Specifies the reduction method ('mean', 'sum', or 'none').
        gamma_type: Strategy used to adapt gamma dynamically across epochs or batches.
        random_seed: Random seed for reproducibility.
        ignore_index: Label index to ignore during loss computation.
        separator_token: Optional token ID used as a boundary marker.
    """
    def get_normalized_alpha(self, alpha) -> Any: ...
    def _build_token_weight_map(self, alpha_dict) -> Any: ...
    """
    Build a mapping from token IDs to their corresponding weights
    based on the provided alpha dictionary.

    Args:
        alpha_dict: Dictionary mapping class or token identifiers
            to their associated weights.

    Returns:
        dict: Mapping from token IDs to weight values.

    Raises:
        ValueError: If token IDs or weights are invalid.
    """
    def _generate_token_weight_mask(self, labels) -> Any: ...
    """
    Generate a weight mask tensor that aligns with the given label tensor.

    Args:
        labels: Tensor of class or token labels for which weights
            need to be applied.

    Returns:
        torch.Tensor: A float tensor of shape matching `labels`,
            containing the weight assigned to each element.

    Raises:
        RuntimeError: If label tensor contains invalid or unmapped token IDs.
    """
    def forward(self, logits, targets) -> Any: ...
    """
    Compute the adaptive focal loss for the given logits and targets.

    Args:
        logits: Predicted unnormalized scores from the model, of shape (..., num_classes).
        targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

    Returns:
        torch.Tensor: Scalar loss value after applying reduction.

    Raises:
        RuntimeError: If computation fails due to invalid shapes,
            numerical instability, or device mismatch.
    """

__all__ = ['ClassWeightedFocalLossWithAdaptiveFocus']
