from typing import Any, Dict, List, Optional, Tuple, Union

class ClassWeightedCrossEntropyLoss:
    """Implements class-weighted cross-entropy loss with per-token weighting."""
    def __init__(self, device, class_weights, reduction, random_seed, ignore_index, separator_token) -> Any: ...
    """
    Initialize the loss module.

    Args:
        device: Target computation device ('cpu' or 'cuda').
        class_weights: Dictionary mapping class labels to (token_ids, weight).
        reduction: Reduction mode ('mean' or 'sum').
        random_seed: Random seed for reproducibility.
        ignore_index: Index to ignore in loss computation.
        separator_token: Optional token ID used as a separator.
    """
    def _build_token_weight_map(self) -> Any: ...
    """
    Builds a mapping from token ID to weight based on provided class weights.

    Returns:
        dict: Token ID to weight mapping.

    Raises:
        ValueError: If token IDs or weights are invalid.
    """
    def _generate_weight_mask(self, labels) -> Any: ...
    """
    Generates a tensor of weights aligned with label tensor.

    Args:
        labels: Tensor of target labels.

    Returns:
        torch.Tensor: Weight tensor.
    """
    def forward(self, logits, targets) -> Any: ...
    """
    Compute the weighted cross-entropy loss.

    Args:
        logits: Model output tensor of shape (..., vocab_size).
        targets: Ground truth tensor of same leading shape as logits (excluding vocab dim).

    Returns:
        torch.Tensor: Scalar loss value.

    Raises:
        RuntimeError: If loss computation fails.
    """
