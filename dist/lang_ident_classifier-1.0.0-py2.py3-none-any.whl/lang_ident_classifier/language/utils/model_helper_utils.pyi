from typing import Any, Dict, List, Optional, Tuple, Union

class CustomFSDPStrategy:
    """
    Unified FSDP strategy for BERT-family and LLaMA-family models.
    Skips FSDP wrapping of BNB 4bit/8bit layers to avoid FP32 shard bloat.
    """
    def __init__(self, ig_params, ig_modules, model_name, is_training) -> Any: ...
    def lightning_restore_optimizer(self) -> Any: ...
    def setup_module(self, module) -> Any: ...
    def lightning_module_state_dict(self) -> Any: ...
    def optimizer_state(self, optimizer) -> Any: ...

class OptunaLoggingCallback:
    """
    Lightning callback that writes trial number to trainer.callback_metrics.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance.

    Behavior:
        On training start it will attempt to add a "trial_number" entry to the
        trainer.callback_metrics mapping. This is best-effort and will not raise
        if metrics are not writable.
    """
    def __init__(self, trial) -> Any: ...
    def on_train_start(self, trainer, pl_module) -> Any: ...

class GPUUsagePruneCallback:
    """
    Callback that monitors GPU usage and prunes an Optuna trial when usage is high.

    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage above which pruning should occur.

    Notes:
        - This callback is conservative: if CUDA is not available it is a no-op.
        - In distributed training it uses a broadcast so all ranks agree.
    """
    def __init__(self, trial, threshold) -> Any: ...
    """
    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage to trigger pruning.
    """
    def _check_gpu_usage(self, trainer) -> Any: ...
    """
    Return True if GPU reserved memory fraction >= threshold.

    Args:
        trainer: Lightning trainer object. Required for `is_global_zero` check.

    Returns:
        bool: True if usage >= threshold, False otherwise.

    Raises:
        None
    """
    def _broadcast_prune_flag(self, flag) -> Any: ...
    """
    Broadcast the boolean prune decision to all ranks.

    Args:
        flag (bool): Local prune decision.

    Returns:
        bool: Agreed prune decision across ranks.

    Raises:
        RuntimeError: If CUDA is expected but not available on broadcast.
    """
    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx, dataloader_idx) -> Any: ...
    """
    Lightning hook executed at start of each training batch.

    Raises:
        optuna.TrialPruned: when GPU usage threshold is exceeded.
    """

class StudyPercentageBasedEarlyStoppingCallback:
    def __init__(self, pct_limit, warmup_n_trials) -> Any: ...
    def __call__(self, study, trial) -> Any: ...

def adjust_local_gpu_rank() -> Any: ...
"""
Compute local GPU rank based on environment variables.

The function inspects `CUDA_VISIBLE_DEVICES`, `LOCAL_RANK` and `RANK` and
returns an integer representing the local GPU index.

Returns:
    int: local GPU rank (0-based). Returns -1 when CUDA is not available.

Raises:
    ValueError: if computed local_rank is out of bounds for visible GPUs.
"""

def get_device_info() -> Any: ...
"""
Collect basic device and host information for logging.

Returns:
    dict: keys include 'gpu_world_size', 'gpu_global_rank', 'gpu_local_rank',
          'node_name', and 'cpu_info'.

Notes:
    - If CUDA is unavailable and SLURM is not detected, gpu_* keys are populated with -1.
"""

def remove_files_except(directory, file_to_keep, log) -> Any: ...
"""
Remove all files in a directory except a single filename to keep.

Args:
    directory (str): Directory to clean.
    file_to_keep (str): Basename of file to retain.
    log (Logger): Logger instance for informational messages.

Raises:
    FileNotFoundError: If `directory` does not exist.
    PermissionError: If file removal fails due to permissions (propagates underlying OSError).
"""

def clear_checkpoints(log, model_config_name, study, trial) -> Any: ...
"""
Clear outdated checkpoint directories for the given model config.

Args:
    log (Logger): Logger instance.
    model_config_name (str): Model configuration name used to build checkpoint root path.
    study (optuna.Study): Optuna study object (kept in signature for compatibility).
    trial (optuna.trial.Trial): Current trial; its number is preserved.

Notes:
    - This function removes directories for older trials (non-current).
    - It will not raise if directories are missing; failures to remove are logged.
"""

def load_checkpoint_with_fsdp(model, fsdp_model, checkpoint_path) -> Any: ...
"""
Load a checkpoint into the original (unwrapped) model when FSDP was used.

Args:
    model: Original (unwrapped) model instance (kept for signature compatibility).
    fsdp_model: FSDP-wrapped model instance that contains `.module`.
    checkpoint_path (str): Path to checkpoint file.

Returns:
    torch.nn.Module: original model with loaded state dict.

Raises:
    FileNotFoundError: If the checkpoint file does not exist.
    AttributeError: If `fsdp_model` does not expose `.module`.
    RuntimeError: If loading state dict fails.
"""

def dequantize_bnb_model(model) -> Any: ...

def manual_dequantize(model) -> Any: ...
"""
Convert any remaining uint8 weights to fp32, in-place.
No reshaping, no heuristics — only dtype fix.
"""

def get_trainable_parameters(model) -> Any: ...
"""
Return the number of trainable parameters in a model.

Args:
    model (torch.nn.Module): Model to inspect.

Returns:
    int: Count of trainable parameters.
"""

def get_target_modules(model, attribute_filter, name_filter, custom_filter, prefix) -> Any: ...
"""
Collect submodules of `model` that satisfy the provided filters.

- Keeps modules that expose a weight Tensor even when that weight is not a Parameter
  (this allows detecting bitsandbytes wrappers like Linear4bit/Linear8bit).
- Skips normalization modules by class-name ("Norm").
- If a module has actual torch.nn.Parameters and all are requires_grad==False, it is skipped.
- Returns dict mapping full dotted module path (prefixed by `prefix` if provided) -> module.

Args:
    model (nn.Module or LightningModule): The model to analyze.
    attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
    name_filter (callable, optional): Function(name) -> bool to filter by module name.
    custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.
    prefix (str, optional): Base name of model path (default: "embedding").

Returns:
    dict: Mapping from *full dotted module path* to module instance for matched modules.

Raises:
    TypeError: If `model` does not implement named_modules().
"""

def clear_gpu_and_cpu_resources() -> Any: ...
"""
Safely clears GPU and CPU memory without disrupting distributed processes.

Notes:
    - Best-effort: this function will not raise on cleanup errors, but will print/log them.
    - Ensures a distributed barrier at the end if torch.distributed is initialized.
"""

def calculate_model_size_in_gb(model) -> Any: ...
"""
Calculate approximate model size in gigabytes.

Args:
    model (torch.nn.Module): The model to analyze.

Returns:
    float: Total size in GB accounting for unique parameters.

Raises:
    TypeError: If model does not implement `.parameters()`.
"""

def get_model_summary(model, depth) -> Any: ...
"""
Return a PrettyTable summary of the model architecture and parameter counts.

Args:
    model (pl.LightningModule): Model to summarize.
    depth (int): How deep in module name hierarchy to report (default 1).

Returns:
    str: Multi-line string summary. If PrettyTable is unavailable this will raise.

Raises:
    TypeError: If model does not implement `named_modules`.
"""

def get_devices_for_trainer(DEVICE) -> Any: ...
"""
Return a devices specification suitable for Lightning Trainer based on DEVICE.

Args:
    DEVICE (str): 'gpu' or 'cpu'.

Returns:
    int | list: devices argument for Trainer (e.g., 1, [0], list(range(n)) or -1 for distributed).

Raises:
    ValueError: If DEVICE is unknown or LOCAL_RANK out of bounds.
"""

def get_supported_compute_dtype() -> Any: ...

def get_pretrained_model_metadata_for_transformers(pretrained_embedding_name) -> Any: ...

def is_duplicate(trial, study) -> Any: ...
"""
Return True when `trial.params` equals parameters of any past trial.

Args:
    trial (optuna.trial.Trial): Trial to check.
    study (optuna.Study): Study to check against.

Returns:
    bool: True if duplicate found, False otherwise.

Raises:
    TypeError: If `trial` or `study` is None or lacks expected attributes.
"""

class NoDuplicateSampler:
    """
    Sampler wrapper that resamples a parameter when a duplicate trial would be created.

    Args:
        base_sampler (optuna.samplers.BaseSampler): Underlying sampler to delegate to.
    """
    def __init__(self, base_sampler) -> Any: ...
    def infer_relative_search_space(self, study, trial) -> Any: ...
    def sample_relative(self, study, trial, search_space) -> Any: ...
    def sample_independent(self, study, trial, param_name, param_distribution) -> Any: ...
    """
    Sample independently using the base sampler. If the proposed parameter
    would create a duplicate trial (all params equal to a past trial),
    resample until unique.

    Args:
        study (optuna.Study)
        trial (optuna.trial.Trial)
        param_name (str)
        param_distribution: distribution object passed by Optuna

    Returns:
        The sampled parameter value.

    Raises:
        RuntimeError: If underlying base_sampler repeatedly fails to produce a non-duplicate
                      after many attempts (guard not implemented here to preserve original behavior).
    """

def gamma_for_tpe_sampler(n) -> Any: ...
"""
Compute gamma parameter for TPESampler.

Args:
    n (int): Number of completed trials.

Returns:
    int: Top 10% of n, capped at 25.
"""

def property_validation(props, name, dtype, required, default, help) -> Any: ...
"""
Retrieve and validate a property from a dot-separated path (e.g. 'app.random_seed', 'run_config.batch_size').

Args:
    props: Loaded YAML properties object (attribute/dict hybrid).
    name: Dot-separated property name (string).
    dtype: Optional type enforcement (e.g. int, float, str, "list[int]", "list[str]", etc.).
    required: If True, raises error when missing. If False, returns default.
    default: Optional fallback value when required=False and key missing.
    help: Optional human-readable hint for fixing config.

Raises:
    AttributeError: If key missing and required=True.
    ValueError: If key exists but value is None.
    TypeError: If dtype enforcement fails.

Returns:
    The retrieved (and possibly cast) value, or default.
"""

def resolve_strategy(strategy_name, frozen_modules, is_training, model_name) -> Any: ...

def get_lora_config(trial, target_modules, lora_task_type, lora_rank, lora_scaling_factor, lora_dropout) -> Any: ...
"""
Construct a PEFT LoraConfig from an Optuna trial's suggested hyperparameters.

Args:
    trial (optuna.trial.Trial): Optuna trial instance to query for hyperparameters.
    target_modules (list): list of target modules (may be empty).
    lora_task_type (Any): TaskType enum or equivalent required by LoraConfig.

Returns:
    LoraConfig: Instance configured according to trial suggestions.

Raises:
    Exception: Propagates exceptions from the underlying LoraConfig constructor or trial queries.
"""

def apply_lora_to_model(model, target_embedding_modules, lora_config, log) -> Any: ...

def merge_lora_into_base(model, log) -> Any: ...

def quantize_model_using_bnb(model) -> Any: ...
"""
Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
Leaves LoRA and trainable modules untouched.
Safe: skips missing weights or broken layers automatically.
"""

def merge_lora_into_base(model, log) -> Any: ...
