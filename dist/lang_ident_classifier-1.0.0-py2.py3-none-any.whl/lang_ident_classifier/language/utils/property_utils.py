import importlib
_mod = importlib.import_module('._property_utils', __package__)
globals().update({k: v for k, v in _mod.__dict__.items() if not k.startswith('__')})
