from typing import Any, Dict, List, Optional, Tuple, Union

class FileDirUtils:
    """
    Utility class for common filesystem operations such as existence checks,
    directory creation, and emptiness validation.

    These helpers wrap standard library calls (os, pathlib, shutil)
    with consistent interfaces and error handling suitable for pipeline utilities.

    Example
    -------
    >>> futil = FileDirUtils()
    >>> futil.check_file_or_dir_exists("/tmp")  
    True
    >>> futil.create_dir("/tmp/example_dir", force_write=True)
    >>> futil.is_dir_empty("/tmp/example_dir")
    True
    """
    def check_file_or_dir_exists(self, file_dir_path) -> Any: ...
    """
    Check whether a given file or directory path exists.

    Parameters
    ----------
    file_dir_path : str
        Absolute or relative path to a file or directory.

    Returns
    -------
    bool
        True if the path exists on disk, False otherwise.

    Raises
    ------
    TypeError
        If `file_dir_path` is not a string or path-like object.
    """
    def create_dir(self, dir_path, force_write) -> Any: ...
    """
    Create a directory (and all intermediate parent directories) if it does not exist.
    Optionally remove an existing directory first if `force_write` is True.

    Parameters
    ----------
    dir_path : str
        Path of the directory to create.
    force_write : bool, optional
        If True, removes the existing directory (and its contents)
        before recreating it. Default is False.

    Returns
    -------
    None

    Raises
    ------
    FileNotFoundError
        If parent directories cannot be created due to missing permissions.
    PermissionError
        If the process lacks permissions to modify or create the directory.
    OSError
        For any other OS-level failure during directory creation or deletion.

    Notes
    -----
    - When `force_write=True`, the entire directory tree is deleted
      using `shutil.rmtree()`. Use with care.
    """
    def is_dir_empty(self, dir_path) -> Any: ...
    """
    Check whether a given directory exists and is empty.

    Parameters
    ----------
    dir_path : str
        Path to the directory to inspect.

    Returns
    -------
    bool
        True if the directory exists and is empty, False otherwise.

    Raises
    ------
    FileNotFoundError
        If the directory does not exist.
    NotADirectoryError
        If the provided path exists but is not a directory.
    PermissionError
        If the directory contents cannot be listed due to permission restrictions.
    """

__all__ = ['FileDirUtils']
