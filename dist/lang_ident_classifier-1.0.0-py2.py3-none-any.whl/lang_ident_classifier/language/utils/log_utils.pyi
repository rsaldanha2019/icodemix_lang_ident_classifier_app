from typing import Any, Dict, List, Optional, Tuple, Union

class RankLoggerAdapter:
    """A LoggerAdapter that allows for a 'rank_zero_only' flag in log calls."""
    def __init__(self, logger, rank) -> Any: ...
    def log(self, level, msg) -> Any: ...

class LogUtils:
    """
    Utility class for application logging configuration and maintenance.

    Provides:
    ----------
    - Creation of a UTC time-based rotating file logger using project properties.
    - Automatic log directory creation under the application's log root.
    - Support for archiving old logs into zip files based on filename prefixes.

    This class ensures consistent logging configuration across distributed components.

    Example
    -------
    >>> props = Properties("/path/to/config.yaml")
    >>> log_util = LogUtils()
    >>> logger = log_util.get_time_rotated_log(props)
    >>> logger.info("Training started successfully.")
    """
    def __init__(self) -> Any: ...
    """
    Initialize the LogUtils class by preparing reusable utility instances.

    Raises
    ------
    RuntimeError
        If dependent utility initialization fails (extremely rare).
    """
    def get_time_rotated_log(self, props) -> Any: ...
    """
    Configure and return a time-rotated logger instance based on application properties.

    This logger writes to a timestamped log file inside a model-specific directory
    under `props.app.logs_dir`. It uses a UTC-based `TimedRotatingFileHandler`
    that rotates daily at midnight (UTC).

    Parameters
    ----------
    props : Properties
        Application configuration object with structured fields:
        - `props.app.model_config_name` : str — name of the current model/config context.
        - `props.app.logs_dir` : str — base directory for logs.
        - `props.logs.prefix` : str — timestamp prefix format (strftime-compatible).
        - `props.logs.suffix` : str — filename suffix (e.g., "run.log").

    Returns
    -------
    logging.Logger
        Configured logger instance with file and stream handlers attached.

    Raises
    ------
    RuntimeError
        If `props` is missing required fields or if log directory cannot be created.
    ValueError
        If the provided prefix format string is invalid.
    OSError
        For underlying OS-level issues during directory or file handler setup.
    """
    def zip_logs_with_prefix(self, archive_log_path, prefix) -> Any: ...
    """
    Archive and remove log files with a specific prefix inside a directory.

    This method scans the specified directory for log files that:
    - Start with the given `prefix`
    - End with `.log`

    It writes all matching files into a new zip archive named `{prefix}_archive.zip`,
    stored in the same directory, then deletes the original `.log` files.

    Parameters
    ----------
    archive_log_path : str
        Path to the directory containing log files.
    prefix : str
        Log filename prefix (typically date-based, e.g., "2025-10-23").

    Returns
    -------
    None

    Raises
    ------
    FileNotFoundError
        If the provided archive_log_path does not exist or is not a directory.
    PermissionError
        If read/write access to the directory or files is denied.
    OSError
        For unexpected I/O errors during zipping or deletion.
    """

__all__ = ['RankLoggerAdapter', 'LogUtils']
