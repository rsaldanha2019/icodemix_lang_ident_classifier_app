from typing import Any, Dict, List, Optional, Tuple, Union

class DateTimeUtils:
    """
    Small utility helper for common date/time operations used across the project.

    Methods are intentionally simple and synchronous (no timezone conversions beyond UTC).
    All returned string timestamps are in UTC unless otherwise noted.

    Example
    -------
    >>> d = DateTimeUtils()
    >>> d.get_utc_datetime_timestamp_string("%Y-%m-%d")
    '2025-10-23'
    >>> d.get_current_time_in_milliseconds()  # returns an int like 1635123456789
    """
    def get_utc_datetime_timestamp_string(self, datetime_format) -> Any: ...
    """
    Format the current UTC time using `datetime_format` (same as datetime.strftime).

    Parameters
    ----------
    datetime_format : str
        A strftime-compatible format string (example: "%Y-%m-%dT%H:%M:%SZ").

    Returns
    -------
    str
        Current UTC time formatted according to `datetime_format`.

    Raises
    ------
    ValueError
        If `datetime_format` is empty or if the resulting formatted string is empty.
    TypeError
        If `datetime_format` is not a string.
    """
    def get_processing_time(self, start_time, end_time) -> Any: ...
    """
    Compute elapsed time between two timestamps (seconds) and return a human-friendly breakdown.

    Parameters
    ----------
    start_time : float
        Start timestamp in seconds (e.g., time.time()).
    end_time : float
        End timestamp in seconds (e.g., time.time()).

    Returns
    -------
    tuple[int, int, int, int, int]
        A tuple of (days, hours, minutes, seconds, milliseconds) representing the
        non-negative elapsed time between `start_time` and `end_time`.

    Behavior notes
    --------------
    - If `end_time < start_time` the function returns zero elapsed time (no negative durations).
    - Milliseconds represent the fractional part of total seconds, rounded down
      to an integer millisecond count (0..999).

    Raises
    ------
    TypeError
        If start_time or end_time are not numeric (int/float).
    """
    def get_current_time_in_milliseconds(self) -> Any: ...
    """
    Return current time in milliseconds since the Unix epoch (UTC).

    Returns
    -------
    int
        Current time in milliseconds (like time.time() * 1000, truncated to int).
    """
    def get_utc_date_time(self) -> Any: ...
    """
    Return current UTC date/time as an ISO-like string (YYYY-MM-DDTHH:MM:SSZ).

    Returns
    -------
    str
        Current UTC time formatted as "%Y-%m-%dT%H:%M:%SZ".
    """
    def get_hms_from_milliseconds(self, milliseconds) -> Any: ...
    """
    Convert a millisecond duration into (hours, minutes, seconds).

    Parameters
    ----------
    milliseconds : int
        Duration in milliseconds.

    Returns
    -------
    tuple[int, int, int]
        (hours, minutes, seconds) corresponding to the duration. Hours are modulo 24
        (i.e., this returns the hh:mm:ss portion rather than total hours).

    Raises
    ------
    TypeError
        If `milliseconds` is not an int or cannot be converted to int.
    """
