from typing import Any, Dict, List, Optional, Tuple, Union

class Properties:
    """
    A lightweight container for hierarchical configuration attributes.

    This class allows dynamic assignment of attributes from dictionaries or YAML files,
    supporting nested structures by recursively setting sub-objects as `Properties`.

    Example
    -------
    >>> p = Properties()
    >>> p.set_attribute("model_name", "BERT")
    >>> p.model_name
    'BERT'
    """
    def set_attribute(self, attr_name, value) -> Any: ...
    """
    Dynamically set an attribute on the Properties object.

    Parameters
    ----------
    attr_name : str
        The name of the attribute to assign.
    value : Any
        The value to be stored in the attribute.

    Returns
    -------
    None

    Raises
    ------
    TypeError
        If `attr_name` is not a string.
    """
    def get_attribute(self, attr_name) -> Any: ...
    """
    Retrieve the value of a given attribute from the Properties object.

    Parameters
    ----------
    attr_name : str
        The name of the attribute to retrieve.

    Returns
    -------
    Any
        The value of the specified attribute.

    Raises
    ------
    AttributeError
        If the specified attribute does not exist.
    TypeError
        If `attr_name` is not a string.
    """

class PropertyUtils:
    """
    Utility class for reading, parsing, and converting configuration properties
    between YAML files, dictionaries, and `Properties` objects.

    Example
    -------
    >>> putils = PropertyUtils()
    >>> props = putils.get_yaml_config_properties("config.yaml")
    >>> props.app.model_name
    'bert-base-tamil'
    """
    def get_props_from_dict(self, props_dict) -> Any: ...
    """
    Convert a dictionary of properties into a nested `Properties` object.

    Parameters
    ----------
    props_dict : dict
        A dictionary containing key-value pairs to convert into attributes.

    Returns
    -------
    Properties
        A `Properties` object mirroring the structure of `props_dict`.

    Raises
    ------
    ValueError
        If the input dictionary is empty.
    TypeError
        If `props_dict` is not a dictionary.
    """
    def get_dict_from_props(self, props) -> Any: ...
    """
    Convert a `Properties` object back into a dictionary recursively.

    Parameters
    ----------
    props : Properties
        The Properties object to convert.

    Returns
    -------
    dict
        A dictionary representation of the Properties object.

    Raises
    ------
    ValueError
        If the Properties object is None or empty.
    TypeError
        If the provided `props` is not an instance of Properties.
    """
    def get_yaml_config_properties(self, config_file) -> Any: ...
    """
    Load a YAML configuration file and return it as a `Properties` object.

    Parameters
    ----------
    config_file : str
        Path to the YAML configuration file.

    Returns
    -------
    Properties
        A `Properties` object containing all fields from the YAML file.

    Raises
    ------
    FileNotFoundError
        If the specified YAML file does not exist.
    YAMLError
        If there is an error parsing the YAML file.
    ValueError
        If the loaded YAML file is empty or invalid.
    RuntimeError
        If an unexpected error occurs during property conversion.
    """

__all__ = ['PropertyUtils', 'Properties']
